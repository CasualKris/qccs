let diceHistory = [];
let diceCount = [0, 0, 0, 0, 0, 0];

function dice() {

  document.getElementById('leftUp').style.visibility='hidden'
  document.getElementById('left').style.visibility='hidden'
  document.getElementById('leftDown').style.visibility='hidden'
  document.getElementById('rightUp').style.visibility='hidden'
  document.getElementById('right').style.visibility='hidden'
  document.getElementById('rightDown').style.visibility='hidden'
  document.getElementById('center').style.visibility='hidden'

  let roll = Math.floor(Math.random() * 6) + 1;
  let result = roll;
  diceHistory.push(result);
  console.log(diceHistory);
  
  //Amount of each rolled number
  let count = --roll;
  ++diceCount[count];
  console.log(diceCount);

  let diceAmountList = document.getElementById("diceAmount"); 
  let diceAmountItem = document.createElement("li" + "br");

  while (diceAmountList.hasChildNodes()) {
    diceAmountList.removeChild(diceAmountList.firstChild);
  }

  let diceLength = diceCount.length;
  for (let i = 0; i < diceLength; i++) {
      diceAmountItem.appendChild(document.createTextNode(diceCount[i]));
      diceAmountList.appendChild(diceAmountItem);
  } 

    // if (result == 1){
    //   document.getElementById('center').style.visibility='visible'    
    // }
    // if (result == 2){
    //   document.getElementById('leftDown').style.visibility='visible'
    //   document.getElementById('rightUp').style.visibility='visible'
    // }
    // if (result == 3){
    //   document.getElementById('leftDown').style.visibility='visible'
    //   document.getElementById('rightUp').style.visibility='visible'
    //   document.getElementById('center').style.visibility='visible'    
    // }
    // if (result == 4){
    //   document.getElementById('leftUp').style.visibility='visible'
    //   document.getElementById('leftDown').style.visibility='visible'
    //   document.getElementById('rightUp').style.visibility='visible'
    //   document.getElementById('rightDown').style.visibility='visible'
    // }
    // if (result == 5){
    //   document.getElementById('leftUp').style.visibility='visible'
    //   document.getElementById('leftDown').style.visibility='visible'
    //   document.getElementById('rightUp').style.visibility='visible'
    //   document.getElementById('rightDown').style.visibility='visible'
    //   document.getElementById('center').style.visibility='visible'    
    // }
    // if (result == 6){ 
    //   document.getElementById('leftUp').style.visibility='visible'
    //   document.getElementById('left').style.visibility='visible'
    //   document.getElementById('leftDown').style.visibility='visible'
    //   document.getElementById('rightUp').style.visibility='visible'
    //   document.getElementById('right').style.visibility='visible'
    //   document.getElementById('rightDown').style.visibility='visible'
    // }

  //List of results
  let diceList = document.getElementById("diceHistory");
  let diceItem = document.createElement("li");
  diceItem.appendChild(document.createTextNode(result));
  diceList.appendChild(diceItem);

  //Average of results
  let sum = 0; 
  diceHistory.forEach(x => {
    sum += x;
  });
  let diceAverage = sum / diceHistory.length;
  document.getElementById("diceAverage").innerHTML = diceAverage.toFixed(2);

  return roll;
}


 